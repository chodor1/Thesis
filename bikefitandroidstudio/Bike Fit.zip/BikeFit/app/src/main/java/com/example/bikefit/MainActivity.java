package com.example.bikefit;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import android.database.Cursor;
import android.provider.OpenableColumns;

import java.net.Socket;
import java.io.DataOutputStream;
import java.io.DataInputStream;

import org.json.JSONObject;
import org.json.JSONException;
import android.util.Base64;

import com.google.android.material.textfield.TextInputEditText;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.Iterator;

import android.text.TextUtils;

import androidx.core.content.FileProvider;

import android.media.MediaMetadataRetriever;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 123;
    private static final String SERVER_IP = "10.0.2.2";
    private static final int SERVER_PORT = 13452;

    private Button btnRecord, btnSelect;
    private TextView tvAnalysisResult, tvLoadingText;
    private ProgressBar progressBarHorizontal;
    private View loadingOverlay;
    private ImageView analysisPreview;
    private TextView tvCurrentAngles;
    private TextInputEditText ageInput, heightInput, saddleHeightInput, medicalHistoryInput;
    private Uri videoUri;

    private ActivityResultLauncher<Intent> videoPickerLauncher;
    private ActivityResultLauncher<Intent> cameraLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupVideoPickerLauncher();
        setupCameraLauncher();
        setupClickListeners();
    }

    private void initializeViews() {
        btnRecord = findViewById(R.id.btnRecord);
        btnSelect = findViewById(R.id.btnSelect);
        tvAnalysisResult = findViewById(R.id.tvAnalysisResult);
        tvLoadingText = findViewById(R.id.tvLoadingText);
        loadingOverlay = findViewById(R.id.loadingOverlay);
        progressBarHorizontal = findViewById(R.id.progressBarHorizontal);
        analysisPreview = findViewById(R.id.analysisPreview);
        tvCurrentAngles = findViewById(R.id.tvCurrentAngles);
        
        ageInput = findViewById(R.id.ageInput);
        heightInput = findViewById(R.id.heightInput);
        saddleHeightInput = findViewById(R.id.saddleHeightInput);
        medicalHistoryInput = findViewById(R.id.medicalHistoryInput);
    }

    private void setupVideoPickerLauncher() {
        videoPickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    videoUri = result.getData().getData();
                    uploadVideo(videoUri);
                }
            }
        );
    }

    private void setupCameraLauncher() {
        cameraLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && videoUri != null) {
                    uploadVideo(videoUri);
                }
            }
        );
    }

    private void setupClickListeners() {
        btnSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermissionAndPickVideo();
            }
        });

        btnRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermissionAndRecordVideo();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, retry the action
                if (permissions[0].equals(Manifest.permission.CAMERA)) {
                    recordVideo();
                } else if (permissions[0].equals(Manifest.permission.READ_EXTERNAL_STORAGE) ||
                         permissions[0].equals(Manifest.permission.READ_MEDIA_VIDEO)) {
                    openVideoPicker();
                }
            } else {
                Toast.makeText(this, "Permission is required to use this feature", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void checkPermissionAndPickVideo() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_VIDEO},
                        PERMISSION_REQUEST_CODE);
            } else {
                openVideoPicker();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST_CODE);
            } else {
                openVideoPicker();
            }
        }
    }

    private void checkPermissionAndRecordVideo() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    PERMISSION_REQUEST_CODE);
        } else {
            recordVideo();
        }
    }

    private boolean validateInputs() {
        boolean isValid = true;
        
        if (TextUtils.isEmpty(ageInput.getText())) {
            ageInput.setError("Please enter age");
            isValid = false;
        }
        
        if (TextUtils.isEmpty(heightInput.getText())) {
            heightInput.setError("Please enter height");
            isValid = false;
        }
        
        if (TextUtils.isEmpty(saddleHeightInput.getText())) {
            saddleHeightInput.setError("Please enter saddle height");
            isValid = false;
        }
        
        return isValid;
    }

    private String readResponse(DataInputStream dis) throws IOException {
        StringBuilder lengthStr = new StringBuilder();
        int b;
        while ((b = dis.read()) != -1) {
            char c = (char) b;
            if (c == ' ') break;
            lengthStr.append(c);
        }

        if (lengthStr.length() == 0) {
            throw new IOException("Invalid response format: empty length");
        }

        try {
            int responseLength = Integer.parseInt(lengthStr.toString().trim());
            
            byte[] responseBytes = new byte[responseLength];
            int totalBytesRead = 0;
            
            while (totalBytesRead < responseLength) {
                int bytesRead = dis.read(responseBytes, totalBytesRead, 
                                       responseLength - totalBytesRead);
                if (bytesRead == -1) {
                    throw new IOException("Connection closed before reading complete response");
                }
                totalBytesRead += bytesRead;
            }

            String jsonResponse = new String(responseBytes, 0, totalBytesRead, "UTF-8");
            
            if (!jsonResponse.startsWith("{") || !jsonResponse.endsWith("}")) {
                throw new IOException("Invalid JSON response format: " + jsonResponse);
            }

            return jsonResponse;

        } catch (NumberFormatException e) {
            throw new IOException("Invalid response length format: " + lengthStr);
        }
    }

    private void handleProgressResponse(JSONObject progressData) {
        String type = progressData.optString("type", "progress");
        
        if ("frame_analysis".equals(type)) {
            final double progress = progressData.optDouble("progress", 0.0);
            String originalMessage = progressData.optString("message", "Processing...");
            final String message = originalMessage.contains("Getting AI recommendations") ? 
                "Analyzing..." : originalMessage;
            
            final String frameBase64 = progressData.optString("frame", "");
            final JSONObject angles = progressData.optJSONObject("angles");
            
            runOnUiThread(() -> {
                updateProgress(message, (int) progress);
                
                if (!frameBase64.isEmpty()) {
                    byte[] decodedBytes = Base64.decode(frameBase64, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                    analysisPreview.setImageBitmap(bitmap);
                    analysisPreview.setVisibility(View.VISIBLE);
                }
                
                if (angles != null) {
                    updateCurrentAngles(angles);
                }
            });
        } else {
            final double progress = progressData.optDouble("progress", 0.0);
            String originalMessage = progressData.optString("message", "Processing...");
            final String message = originalMessage.contains("Getting AI recommendations") ? 
                "Analyzing..." : originalMessage;
            
            runOnUiThread(() -> {
                updateProgress(message, (int) progress);
            });
        }
    }

    private void updateCurrentAngles(JSONObject angles) {
        StringBuilder angleText = new StringBuilder("Current Angles:\n");
        try {
            Iterator<String> keys = angles.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                double value = angles.getDouble(key);
                angleText.append(String.format("%s: %.1f°\n", key, value));
            }
            tvCurrentAngles.setText(angleText.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private byte[] compressVideo(Uri videoUri) throws IOException {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(this, videoUri);
        
        // Get original dimensions
        String width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
        String height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
        
        // Calculate new dimensions (reduce to 25% for faster transfer)
        int newWidth = Integer.parseInt(width) / 4;
        int newHeight = Integer.parseInt(height) / 4;

        // Read the video file in chunks
        InputStream inputStream = getContentResolver().openInputStream(videoUri);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        
        byte[] buffer = new byte[8192];
        int bytesRead;
        int totalBytes = 0;
        
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, bytesRead);
            totalBytes += bytesRead;
            int progress = (int)((totalBytes / (float)inputStream.available()) * 20);
            runOnUiThread(() -> {
                updateProgress("Compressing video...", progress);
            });
        }
        
        inputStream.close();
        byte[] videoData = outputStream.toByteArray();
        outputStream.close();
        
        return videoData;
    }

    private void uploadVideo(Uri videoUri) {
        if (!validateInputs()) {
            return;
        }

        showLoading(true);
        tvAnalysisResult.setText("");

        new Thread(() -> {
            Socket socket = null;
            try {
                // Compress video first
                byte[] compressedVideo = compressVideo(videoUri);
                String videoBase64 = Base64.encodeToString(compressedVideo, Base64.DEFAULT);

                JSONObject userDetails = new JSONObject();
                userDetails.put("age", Integer.parseInt(ageInput.getText().toString()));
                userDetails.put("height", Float.parseFloat(heightInput.getText().toString()));
                userDetails.put("saddle_height", Float.parseFloat(saddleHeightInput.getText().toString()));
                String medicalHistory = medicalHistoryInput.getText().toString().trim();
                if (!medicalHistory.isEmpty()) {
                    userDetails.put("medical_history", medicalHistory);
                }

                JSONObject jsonRequest = new JSONObject();
                jsonRequest.put("command", "analyze_video");
                jsonRequest.put("video_data", videoBase64);
                jsonRequest.put("user_details", userDetails);

                String jsonString = jsonRequest.toString();

                socket = new Socket(SERVER_IP, SERVER_PORT);
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                DataInputStream dis = new DataInputStream(socket.getInputStream());

                String message = jsonString.length() + " " + jsonString;
                dos.writeBytes(message);
                dos.flush();

                while (true) {
                    String jsonResponse = readResponse(dis);
                    JSONObject responseJson = new JSONObject(jsonResponse);
                    String status = responseJson.getString("status");

                    if ("progress".equals(status)) {
                        JSONObject progressData = responseJson.getJSONObject("data");
                        handleProgressResponse(progressData);
                    } else if ("success".equals(status)) {
                        JSONObject data = responseJson.getJSONObject("data");
                        String recommendations = data.getString("recommendations");
                        runOnUiThread(() -> {
                            showLoading(false);
                            tvAnalysisResult.setText(recommendations);
                        });
                        break;
                    } else if ("error".equals(status)) {
                        throw new IOException("Analysis failed: " + 
                            responseJson.getString("message"));
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    showLoading(false);
                    Toast.makeText(MainActivity.this,
                            "Error: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                    tvAnalysisResult.setText("Error occurred: " + e.getMessage());
                });
            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    private void showLoading(boolean show) {
        runOnUiThread(() -> {
            loadingOverlay.setVisibility(show ? View.VISIBLE : View.GONE);
            btnRecord.setEnabled(!show);
            btnSelect.setEnabled(!show);
            
            if (show) {
                tvLoadingText.setText("Preparing video for analysis...");
                progressBarHorizontal.setProgress(0);
            }
        });
    }

    private void updateProgress(String message, int progress) {
        runOnUiThread(() -> {
            tvLoadingText.setText(message);
            progressBarHorizontal.setProgress(progress);
        });
    }

    private void openVideoPicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("video/*");
        videoPickerLauncher.launch(intent);
    }

    private void recordVideo() {
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        File videoFile = new File(getExternalFilesDir(null), "recorded_video.mp4");
        videoUri = FileProvider.getUriForFile(this,
                getApplicationContext().getPackageName() + ".provider",
                videoFile);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, videoUri);
        intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 30);
        intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        cameraLauncher.launch(intent);
    }
}
